(function() {
  $(function() {
    if ($('.slick-slide').length <= 1) {
      return $('.slide-arrow').addClass('hide');
    }
  });

}).call(this);
