(function() {
  $(function() {
    return $('#new_subscriber').validate();
  });

}).call(this);
